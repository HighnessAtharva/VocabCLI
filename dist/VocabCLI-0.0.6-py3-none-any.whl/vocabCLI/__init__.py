"""
Vocabulary Builder
"""
